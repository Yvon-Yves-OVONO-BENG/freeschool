<?php

namespace App\Controller\Registration;

use App\Repository\ClassroomRepository;
use App\Repository\SchoolRepository;
use App\Service\SolvableAllService;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;

#[IsGranted('ROLE_USER', message: 'Accès refusé. Connectez-vous')]
#[Route("/registration")]
class PrintStudentSolvableAllController extends AbstractController
{
    public function __construct(
        protected SchoolRepository $schoolRepository,
        protected SolvableAllService $solvableAllService, 
        protected ClassroomRepository $classroomRepository, 
        ){}

    #[Route("/print-student-solvable-all", name:"print_student_solvable_all")]
    public function printStudentSolvableAll(Request $request): Response
    {
        $mySession = $request->getSession();
        #mes variables témoin pour afficher les sweetAlert
        $mySession->set('ajout',null);
        $mySession->set('suppression', null);
        $mySession->set('miseAjour', null);
        $mySession->set('saisiNotes', null);
        if(!$mySession)
        {
            return $this->redirectToRoute("app_logout");
        }
        
        $schoolYear = $mySession->get('schoolYear');
        $subSystem = $mySession->get('subSystem');
        $school = $this->schoolRepository->findOneBySchoolYear(['schoolYear' => $schoolYear]);

        $classrooms = $this->classroomRepository->findBy([ 'schoolYear' => $schoolYear]);

        $pdf = $this->solvableAllService->printStudentSolvableAll($classrooms, $school, $schoolYear);

        if ($subSystem->getId() == 1 ) 
        {
            return new Response($pdf->Output(utf8_decode("All Students solvables"), "I"), 200, ['content-type' => 'application/pdf']);
        } 
        else 
        {
            return new Response($pdf->Output(utf8_decode("Tous les élèves solvables"), "I"), 200, ['content-type' => 'application/pdf']);
        }
    }


}
